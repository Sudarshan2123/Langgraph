"""Match old sections to new sections: exact title -> fuzzy title/text -> unmatched (added/removed)."""
import re
from difflib import SequenceMatcher
from .parser import Section


def _norm(t):
    return re.sub(r"[^a-z0-9 ]", "", re.sub(r"^\s*[\d.]+\s*", "", t.lower())).strip()


def align(old: list[Section], new: list[Section]):
    """Returns list of (old_or_None, new_or_None) in new-document order, removals placed near neighbours."""
    unmatched_old = list(range(len(old)))
    pairs = []

    def take(pred):
        for i in unmatched_old:
            if pred(old[i]):
                unmatched_old.remove(i)
                return i
        return None

    for n in new:
        key = _norm(n.title)
        i = take(lambda o: _norm(o.title) == key)
        if i is None:
            def similar(o):
                title_sim = SequenceMatcher(None, _norm(o.title), key).ratio()
                text_sim = SequenceMatcher(None, o.text[:800], n.text[:800]).quick_ratio() if o.text and n.text else 0
                return title_sim > 0.85 or (title_sim > 0.5 and text_sim > 0.8)
            i = take(similar)
        pairs.append((old[i] if i is not None else None, n, i))

    result, removed = [], {i: old[i] for i in unmatched_old}
    last_old = -1
    for o, n, i in pairs:
        if i is not None:
            for r in [k for k in sorted(removed) if last_old < k < i]:
                result.append((removed.pop(r), None))
            last_old = i
        result.append((o, n))
    result.extend((removed[k], None) for k in sorted(removed))
    return result
