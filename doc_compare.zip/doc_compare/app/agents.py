"""Parallel section agents (fast model) + one synthesis call (stronger model)."""
import asyncio, json, os
from anthropic import AsyncAnthropic

FAST = os.getenv("CLAUDE_FAST_MODEL", "claude-haiku-5-5")
SYNTH = os.getenv("CLAUDE_SYNTH_MODEL", "claude-sonnet-5-5")
_client = None
_sem = None


def client():
    global _client
    _client = _client or AsyncAnthropic()
    return _client


def sem():
    global _sem
    _sem = _sem or asyncio.Semaphore(int(os.getenv("MAX_CONCURRENCY", "8")))
    return _sem


SECTION_SYSTEM = """You compare one section of an OLD and NEW version of a document.
You receive the precomputed differences (removed/added sentences, table row changes).
Reply with ONLY a JSON object:
{"change_type": "added|removed|modified|reworded|formatting_only",
 "impact": "high|medium|low",
 "summary": "1-2 plain sentences on what changed and why it matters",
 "key_points": ["short bullet on each material change, with exact numbers/dates/names"],
 "theme": "2-3 word topic label, e.g. Payment terms",
 "confidence": 0.0-1.0}
Impact: high = changes obligations, money, dates, scope, definitions, safety or compliance; medium = meaningful but non-binding; low = wording, typos, renumbering.
Never invent content that is not in the differences."""

SYNTH_SYSTEM = """You write the executive layer of a document comparison report from a JSON change log.
Reply with ONLY a JSON object:
{"executive_summary": "150-250 words, plain prose, lead with the most important changes",
 "themes": [{"title": "...", "summary": "2-3 sentences", "sections": ["section titles"]}],
 "risks": ["items a reviewer must verify first"]}
Use only facts in the change log."""


def _json(text):
    s, e = text.find("{"), text.rfind("}")
    return json.loads(text[s:e + 1])


def _clip(items, n=12, width=500):
    return [i[:width] for i in items[:n]] + ([f"... +{len(items) - n} more"] if len(items) > n else [])


async def analyze_section(d) -> dict:
    payload = {"section": d.title, "status": d.status, "removed": _clip(d.removed), "added": _clip(d.added), "tables": d.tables[:3]}
    base = {"id": d.idx, "section": d.title, "status": d.status, "page_old": d.page_old, "page_new": d.page_new,
            "removed": _clip(d.removed, 4, 350), "added": _clip(d.added, 4, 350), "tables": d.tables[:3]}
    async with sem():
        for attempt in range(2):
            try:
                r = await client().messages.create(
                    model=FAST, max_tokens=700,
                    system=[{"type": "text", "text": SECTION_SYSTEM, "cache_control": {"type": "ephemeral"}}],
                    messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)[:14000]}])
                out = _json(r.content[0].text)
                out["needs_review"] = float(out.get("confidence", 1)) < 0.6
                return {**base, **out}
            except Exception as e:
                err = str(e)
                await asyncio.sleep(1 + attempt)
    return {**base, "change_type": d.status, "impact": "medium", "summary": "Automatic analysis failed; review this section manually.",
            "key_points": [], "theme": "Unanalyzed", "confidence": 0, "needs_review": True, "error": err}


async def synthesize(findings: list[dict]) -> dict:
    log = [{k: f.get(k) for k in ("section", "impact", "change_type", "summary", "key_points", "theme")} for f in findings]
    order = {"high": 0, "medium": 1, "low": 2}
    log.sort(key=lambda f: order.get(f["impact"], 1))
    try:
        r = await client().messages.create(
            model=SYNTH, max_tokens=1800,
            system=[{"type": "text", "text": SYNTH_SYSTEM, "cache_control": {"type": "ephemeral"}}],
            messages=[{"role": "user", "content": json.dumps(log, ensure_ascii=False)[:90000]}])
        return _json(r.content[0].text)
    except Exception as e:
        return {"executive_summary": f"Summary generation failed ({e}). See the change log below.", "themes": [], "risks": []}


VERIFY_MODEL = os.getenv("CLAUDE_VERIFY_MODEL", FAST)
VERIFY_SYSTEM = """You fact-check a summary of a document change against the evidence (removed/added text, table changes).
Reply with ONLY JSON: {"supported": true|false, "note": "what is wrong, or empty", "corrected_summary": "fixed 1-2 sentences, or empty"}
supported=false if any number, date, name, direction of change (increase/decrease, added/removed) or obligation in the summary or key_points is not backed by the evidence."""


async def verify_finding(f: dict) -> dict:
    evidence = {"summary": f.get("summary"), "key_points": f.get("key_points"), "removed": f.get("removed"),
                "added": f.get("added"), "tables": f.get("tables")}
    async with sem():
        for attempt in range(2):
            try:
                r = await client().messages.create(
                    model=VERIFY_MODEL, max_tokens=400,
                    system=[{"type": "text", "text": VERIFY_SYSTEM, "cache_control": {"type": "ephemeral"}}],
                    messages=[{"role": "user", "content": json.dumps(evidence, ensure_ascii=False)[:12000]}])
                out = _json(r.content[0].text)
                return {"id": f["id"], "section": f["section"], "supported": bool(out.get("supported", True)),
                        "note": out.get("note", ""), "corrected_summary": out.get("corrected_summary", "")}
            except Exception:
                await asyncio.sleep(1 + attempt)
    return {"id": f["id"], "section": f["section"], "supported": False, "note": "Verifier unavailable; check manually.", "corrected_summary": ""}
