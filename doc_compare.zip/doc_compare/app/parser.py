"""Parse DOCX/PDF into a common structure: sections with title, page, text, tables."""
import os, re, statistics
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Section:
    title: str
    level: int = 1
    page: int = 1
    text: str = ""
    tables: list = field(default_factory=list)  # each table = list of rows (list[str])


def parse(path: str) -> list[Section]:
    ext = Path(path).suffix.lower()
    if ext == ".docx":
        return _parse_docx(path)
    if ext == ".pdf":
        if os.getenv("PDF_PARSER", "docling") == "docling":
            try:
                return _parse_pdf_docling(path)
            except Exception as e:  # fall back so the user is never blocked
                print(f"[parser] docling failed ({e}); using PyMuPDF")
        return _parse_pdf_pymupdf(path)
    raise ValueError(f"Unsupported file type: {ext}")


# ---------- DOCX ----------
def _parse_docx(path):
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    doc = Document(path)
    sections, cur = [], Section("Preamble", 0)
    for child in doc.element.body.iterchildren():
        if child.tag.endswith("}p"):
            p = Paragraph(child, doc)
            style = (p.style.name or "") if p.style is not None else ""
            txt = p.text.strip()
            if not txt:
                continue
            m = re.match(r"Heading (\d+)", style)
            if m or style == "Title":
                sections.append(cur)
                cur = Section(txt, int(m.group(1)) if m else 0)
            else:
                cur.text += txt + "\n"
        elif child.tag.endswith("}tbl"):
            t = Table(child, doc)
            rows = [[c.text.strip() for c in r.cells] for r in t.rows]
            if rows:
                cur.tables.append(rows)
    sections.append(cur)
    return [s for s in sections if s.text.strip() or s.tables or s.title != "Preamble"]


# ---------- PDF (Docling) ----------
_converter = None


def _parse_pdf_docling(path):
    global _converter
    from docling.document_converter import DocumentConverter

    _converter = _converter or DocumentConverter()
    doc = _converter.convert(path).document
    sections, cur = [], Section("Preamble", 0, 1)
    for item, level in doc.iterate_items():
        label = getattr(item.label, "value", str(item.label))
        page = item.prov[0].page_no if getattr(item, "prov", None) else cur.page
        if label in ("page_header", "page_footer"):
            continue  # kills false "changes" from repeating headers/footers
        if label in ("section_header", "title"):
            sections.append(cur)
            cur = Section(item.text.strip(), max(level, 1), page)
        elif label == "table":
            try:
                df = item.export_to_dataframe(doc)
            except TypeError:
                df = item.export_to_dataframe()
            rows = [[str(c) for c in df.columns]] + df.astype(str).values.tolist()
            cur.tables.append(rows)
        elif hasattr(item, "text") and item.text.strip():
            cur.text += item.text.strip() + "\n"
    sections.append(cur)
    return [s for s in sections if s.text.strip() or s.tables or s.title != "Preamble"]


# ---------- PDF (PyMuPDF, fast fallback) ----------
def _parse_pdf_pymupdf(path):
    import pymupdf as fitz

    pdf = fitz.open(path)
    items = []  # (page, y, kind, payload, size, bold); tables sit in reading order with the text
    for pno, page in enumerate(pdf, 1):
        tabs = []
        try:
            tabs = page.find_tables().tables
        except Exception:
            pass
        tbboxes = [fitz.Rect(t.bbox) for t in tabs]
        for t, bb in zip(tabs, tbboxes):
            rows = [[str(c or "").strip() for c in r] for r in t.extract()]
            if rows:
                items.append((pno, bb.y0, "table", rows, 0, False))
        for b in page.get_text("dict")["blocks"]:
            if b.get("type") != 0 or any(fitz.Rect(b["bbox"]).intersects(r) for r in tbboxes):
                continue
            for ln in b["lines"]:
                spans = [sp for sp in ln["spans"] if sp["text"].strip()]
                if spans:
                    txt = " ".join(sp["text"].strip() for sp in spans)
                    items.append((pno, ln["bbox"][1], "text", txt, max(sp["size"] for sp in spans), any(sp["flags"] & 16 for sp in spans)))
    items.sort(key=lambda i: (i[0], i[1]))

    # drop repeating headers/footers (same text once digits are stripped, on >40% of pages)
    norm = lambda t: re.sub(r"\d+", "#", t.strip().lower())
    pages_of = {}
    for pno, _, kind, val, *_ in items:
        if kind == "text":
            pages_of.setdefault(norm(val), set()).add(pno)
    n_pages = max(len(pdf), 1)
    items = [i for i in items if i[2] == "table" or n_pages < 5 or len(pages_of[norm(i[3])]) / n_pages <= 0.4]

    sizes = [i[4] for i in items if i[2] == "text"]
    body = statistics.median(sizes) if sizes else 10
    sections, cur, heading_open, pending_name = [], Section("Preamble", 0, 1), False, False
    for pno, _, kind, val, size, bold in items:
        if kind == "table":
            if cur.tables and cur.page != pno and _continues(cur.tables[-1], val):
                cur.tables[-1].extend(val[1:] if val[:1] == cur.tables[-1][:1] else val)  # stitch split tables
            else:
                cur.tables.append(val)
        elif _is_heading(val, size, bold, body) or pending_name:
            title = re.sub(r"^Policy Name:\s*", "", val).strip()
            if pending_name and title:  # name sat on the line after a bare "Policy Name:" label
                cur.title = (cur.title + " " + title).strip()
                pending_name = False
            elif heading_open and cur.page == pno and len(cur.title) < 160:
                cur.title = (cur.title + " " + title).strip()  # multi-line heading: merge
            else:
                sections.append(cur)
                cur = Section(title, 1, pno)
                pending_name = not title
            heading_open = True
            continue
        else:
            cur.text += val + "\n"
        heading_open = False
    sections.append(cur)
    return [s for s in sections if s.text.strip() or s.tables or s.title != "Preamble"]


_NUM_HEAD = re.compile(r"^\d{1,2}(\.\d{1,2})+\.\s+[A-Z]")  # "1.6. Roles and Responsibilities"


def _is_heading(txt, size, bold, body):
    """Font cues first; then text patterns for documents whose headings look like body text."""
    if len(txt) >= 120:
        return False
    if size >= body * 1.15 or (bold and size >= body and len(txt.split()) < 12):
        return True
    return bool(_NUM_HEAD.match(txt) or txt.startswith("Policy Name:"))


def _continues(prev, nxt):
    return len(prev[0]) == len(nxt[0]) if prev and nxt else False
