"""Cheap deterministic diff. Unchanged sections never reach the LLM."""
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher


@dataclass
class SectionDiff:
    idx: int
    title: str
    status: str  # added | removed | modified | unchanged
    page_old: int | None = None
    page_new: int | None = None
    removed: list = field(default_factory=list)
    added: list = field(default_factory=list)
    tables: list = field(default_factory=list)

    @property
    def changed(self):
        return self.status != "unchanged"


def _sentences(text):
    parts = re.split(r"(?<=[.!?;:])\s+|\n+", re.sub(r"[ \t]+", " ", text))
    return [p.strip() for p in parts if p.strip()]


def diff_text(a: str, b: str):
    sa, sb = _sentences(a), _sentences(b)
    rem, add = [], []
    for tag, i1, i2, j1, j2 in SequenceMatcher(None, sa, sb, autojunk=False).get_opcodes():
        if tag != "equal":
            rem += sa[i1:i2]
            add += sb[j1:j2]
    return rem, add


def _flat(t):
    return re.sub(r"\s+", " ", t or "").strip()


def diff_table(a, b, n):
    key = lambda r: _flat(r[0] if r else "").lower()
    ma, mb = {}, {}
    for r in a[1:]:
        ma.setdefault(key(r), r)
    for r in b[1:]:
        mb.setdefault(key(r), r)
    out = {"table": n, "header_changed": a[:1] != b[:1], "header_old": a[0] if a else [], "header_new": b[0] if b else [],
           "added": [r for k, r in mb.items() if k not in ma],
           "removed": [r for k, r in ma.items() if k not in mb], "changed": []}
    for k in ma.keys() & mb.keys():
        cells = []
        for c, x in enumerate(ma[k]):
            y = mb[k][c] if c < len(mb[k]) else ""
            if _flat(x) == _flat(y):
                continue
            rem, add = diff_text(_flat(x), _flat(y))  # long cells: report only the sentences that differ
            cells.append({"col": (b[0][c] if c < len(b[0]) else c), "old": " ".join(rem) or _flat(x)[:300],
                          "new": " ".join(add) or _flat(y)[:300]})
        if cells:
            out["changed"].append({"key": ma[k][0], "cells": cells})
    return out if (out["added"] or out["removed"] or out["changed"] or out["header_changed"]) else None


def diff_pair(idx, old, new) -> SectionDiff:
    if old is None:
        return SectionDiff(idx, new.title, "added", None, new.page, added=_sentences(new.text), tables=[{"table": i + 1, "added": t[1:], "removed": [], "changed": []} for i, t in enumerate(new.tables)])
    if new is None:
        return SectionDiff(idx, old.title, "removed", old.page, None, removed=_sentences(old.text), tables=[{"table": i + 1, "added": [], "removed": t[1:], "changed": []} for i, t in enumerate(old.tables)])
    rem, add = diff_text(old.text, new.text)
    tdiffs = []
    for i in range(max(len(old.tables), len(new.tables))):
        a = old.tables[i] if i < len(old.tables) else []
        b = new.tables[i] if i < len(new.tables) else []
        d = diff_table(a, b, i + 1) if a and b else (
            {"table": i + 1, "added": b[1:], "removed": [], "changed": []} if b else {"table": i + 1, "added": [], "removed": a[1:], "changed": []})
        if d:
            tdiffs.append(d)
    status = "modified" if (rem or add or tdiffs or old.title.strip() != new.title.strip()) else "unchanged"
    return SectionDiff(idx, new.title, status, old.page, new.page, rem, add, tdiffs)
