"""PDF version of the report (pure Python via reportlab, no system libraries needed)."""
from datetime import date
from xml.sax.saxutils import escape as x
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

ORDER = {"high": 0, "medium": 1, "low": 2}


def _pg(f):
    return f"old p.{f.get('page_old') or '-'} / new p.{f.get('page_new') or '-'}"


def build(path, old_name, new_name, stats, synthesis, findings):
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=10, leading=14)
    small = ParagraphStyle("s", parent=body, fontSize=8, leading=10)
    h1, h2 = ss["Heading1"], ss["Heading2"]
    P = lambda t, s=body: Paragraph(t, s)
    s = []
    s += [P("Document Comparison Report", ss["Title"]),
          P(f"Old version: {x(old_name)}<br/>New version: {x(new_name)}<br/>Generated: {date.today():%d %b %Y}"),
          Spacer(1, 6),
          P(f"{stats['changed']} of {stats['total']} sections changed "
            f"({sum(f.get('impact') == 'high' for f in findings)} high impact).")]

    s += [P("1. Executive summary", h1), P(x(synthesis.get("executive_summary", "")))]
    if synthesis.get("risks"):
        s += [P("Verify first", h2)] + [P("• " + x(r)) for r in synthesis["risks"]]

    s.append(P("2. Key changes by theme", h1))
    for t in synthesis.get("themes", []):
        s += [P(x(t.get("title", "")), h2), P(x(t.get("summary", "")))]
        if t.get("sections"):
            s.append(P("<i>Sections: " + x("; ".join(t["sections"])) + "</i>", small))

    s.append(P("3. High-impact changes", h1))
    for f in sorted([f for f in findings if f.get("impact") == "high"], key=lambda f: f["id"]):
        s += [P(f"{x(f['section'])} <font size=8 color='#5d6678'>({_pg(f)})</font>", h2), P(x(f.get("summary", "")))]
        s += [P("• " + x(k)) for k in f.get("key_points", [])]
        for label, items, col in (("Old", f.get("removed", []), "#a93226"), ("New", f.get("added", []), "#16744a")):
            s += [P(f"<font color='{col}'><b>{label}:</b></font> {x(t)}", small) for t in items[:3]]
        if f.get("needs_review"):
            s.append(P("<b>Flagged for human review (low confidence).</b>", small))

    s += [PageBreak(), P("Appendix A. Full change log", h1)]
    rows = [["#", "Section", "Pages", "Type", "Impact", "Summary"]]
    for i, f in enumerate(sorted(findings, key=lambda f: (ORDER.get(f.get("impact"), 1), f["id"])), 1):
        rows.append([str(i), P(x(f["section"]), small), P(_pg(f), small), f.get("change_type", ""), f.get("impact", ""),
                     P(x(f.get("summary", "")) + (" <b>[REVIEW]</b>" if f.get("needs_review") else ""), small)])
    t = Table(rows, repeatRows=1, colWidths=[8*mm, 38*mm, 24*mm, 20*mm, 16*mm, 64*mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f3a5f")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                           ("FONTSIZE", (0, 0), (-1, -1), 8), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#d9d6cc")),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f6f5f1")])]))
    s.append(t)

    s.append(P("Appendix B. Method and limitations", h1))
    for m in ["Both files were parsed with the same parser; repeating headers and footers were removed.",
              "Sections were matched by heading, then fuzzy title/text similarity; unmatched ones are reported as added or removed.",
              f"{stats['total'] - stats['changed']} unchanged sections were skipped without AI analysis.",
              "Tables were compared row by row using the first column as key.",
              "Verify numbers, dates and legal wording against the source documents. Scanned pages may contain OCR errors."]:
        s.append(P("• " + m))

    def footer(c, d):
        c.setFont("Helvetica", 8)
        c.drawRightString(A4[0] - 15*mm, 10*mm, f"Page {d.page}")

    SimpleDocTemplate(path, pagesize=A4, leftMargin=15*mm, rightMargin=15*mm, topMargin=15*mm, bottomMargin=18*mm,
                      title="Document Comparison Report").build(s, onFirstPage=footer, onLaterPages=footer)
