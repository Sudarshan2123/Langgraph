"""Build the final .docx from the structured change log. No LLM calls: instant."""
from datetime import date
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

RED, GREEN = RGBColor(0xB4, 0x23, 0x18), RGBColor(0x1B, 0x7F, 0x4B)
ORDER = {"high": 0, "medium": 1, "low": 2}


def _pg(f):
    o, n = f.get("page_old"), f.get("page_new")
    return f"old p.{o or '-'} / new p.{n or '-'}"


def build(path, old_name, new_name, stats, synthesis, findings):
    d = Document()
    d.styles["Normal"].font.name = "Calibri"
    d.styles["Normal"].font.size = Pt(10.5)
    d.add_heading("Document Comparison Report", 0)
    d.add_paragraph(f"Old version: {old_name}\nNew version: {new_name}\nGenerated: {date.today():%d %b %Y}")
    hi = sum(f.get("impact") == "high" for f in findings)
    d.add_paragraph(f"{stats['changed']} of {stats['total']} sections changed ({hi} high impact).")

    d.add_heading("1. Executive summary", 1)
    d.add_paragraph(synthesis.get("executive_summary", ""))
    if synthesis.get("risks"):
        d.add_heading("Verify first", 2)
        for r in synthesis["risks"]:
            d.add_paragraph(r, style="List Bullet")

    d.add_heading("2. Key changes by theme", 1)
    for t in synthesis.get("themes", []):
        d.add_heading(t.get("title", ""), 2)
        d.add_paragraph(t.get("summary", ""))
        if t.get("sections"):
            p = d.add_paragraph("Sections: " + "; ".join(t["sections"]))
            p.runs[0].italic = True

    d.add_heading("3. High-impact changes", 1)
    for f in sorted([f for f in findings if f.get("impact") == "high"], key=lambda f: f["id"]):
        d.add_heading(f"{f['section']}  ({_pg(f)})", 2)
        d.add_paragraph(f.get("summary", ""))
        for k in f.get("key_points", []):
            d.add_paragraph(k, style="List Bullet")
        for label, items, col in (("Old", f.get("removed", []), RED), ("New", f.get("added", []), GREEN)):
            for s in items[:3]:
                p = d.add_paragraph()
                r = p.add_run(f"{label}: ")
                r.bold, r.font.color.rgb = True, col
                p.add_run(s)
        if f.get("needs_review"):
            d.add_paragraph("Flagged for human review (low confidence).").runs[0].bold = True

    d.add_heading("Appendix A. Full change log", 1)
    tbl = d.add_table(rows=1, cols=6)
    tbl.style = "Light Grid Accent 1"
    for c, h in zip(tbl.rows[0].cells, ["#", "Section", "Pages", "Type", "Impact", "Summary"]):
        c.text = h
    for i, f in enumerate(sorted(findings, key=lambda f: (ORDER.get(f.get("impact"), 1), f["id"])), 1):
        row = tbl.add_row().cells
        for c, v in zip(row, [str(i), f["section"], _pg(f), f.get("change_type", ""), f.get("impact", ""),
                              f.get("summary", "") + (" [REVIEW]" if f.get("needs_review") else "")]):
            c.text = v

    d.add_heading("Appendix B. Method and limitations", 1)
    for s in ["Both files were parsed with the same parser; repeating headers and footers were removed.",
              "Sections were matched by heading, then by fuzzy title/text similarity. Unmatched sections are reported as added or removed.",
              f"{stats['total'] - stats['changed']} unchanged sections were skipped without AI analysis.",
              "Changed sections were summarized by an AI model from computed differences; tables were compared row by row using the first column as key.",
              "Verify numbers, dates and legal wording against the source documents before relying on this report. Scanned pages may contain OCR errors."]:
        d.add_paragraph(s, style="List Bullet")
    d.save(path)
