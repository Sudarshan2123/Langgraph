"""LangGraph workflow.

START -> parse_diff --(Send per changed section)--> analyze x N -> gather
      --(Send per high-impact / low-confidence finding)--> verify x M -> synthesize -> report -> END
Shortcuts: no changes -> synthesize; nothing to verify -> synthesize.
Progress goes out through the custom stream; state is checkpointed so a failed run can resume.
"""
import asyncio, operator, os
from dataclasses import asdict
from typing import Annotated, TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.config import get_stream_writer
from langgraph.graph import END, START, StateGraph
from langgraph.types import Send

from . import agents, aligner, differ, parser, report, report_pdf

VERIFY = os.getenv("VERIFY_HIGH_IMPACT", "1") == "1"


class State(TypedDict, total=False):
    job_id: str
    old_path: str
    new_path: str
    old_name: str
    new_name: str
    out_dir: str
    stage: str
    diffs: list                                  # changed sections only (plain dicts, checkpoint-friendly)
    stats: dict
    findings: Annotated[list, operator.add]      # parallel analyze branches append here
    verdicts: Annotated[list, operator.add]      # parallel verify branches append here
    final_findings: list
    synthesis: dict
    report_paths: dict


def _emit(event, data):
    get_stream_writer()({"event": event, "data": data})


# ---------- nodes ----------
async def parse_diff(state: State):
    _emit("status", {"stage": "Parsing both documents"})
    old, new = await asyncio.gather(asyncio.to_thread(parser.parse, state["old_path"]),
                                    asyncio.to_thread(parser.parse, state["new_path"]))
    _emit("status", {"stage": "Aligning sections"})
    pairs = await asyncio.to_thread(aligner.align, old, new)
    all_diffs = [differ.diff_pair(i, o, n) for i, (o, n) in enumerate(pairs)]
    changed = [d for d in all_diffs if d.changed]
    changed.sort(key=lambda d: -(len(d.tables) * 5 + len(d.added) + len(d.removed)))  # likely-important first
    stats = {"total": len(all_diffs), "changed": len(changed)}
    _emit("stats", stats)
    _emit("status", {"stage": f"Analyzing {len(changed)} changed sections"})
    return {"diffs": [asdict(d) for d in changed], "stats": stats}


async def analyze(payload: dict):
    f = await agents.analyze_section(differ.SectionDiff(**payload["diff"]))
    _emit("finding", {"finding": f, "of": payload["of"]})
    return {"findings": [f]}


async def gather(state: State):
    return {"stage": "analysis complete"}  # fan-in barrier: runs once, after every analyze branch


async def verify(payload: dict):
    v = await agents.verify_finding(payload["finding"])
    _emit("verified", v)
    return {"verdicts": [v]}


async def synthesize(state: State):
    verdicts = {v["id"]: v for v in state.get("verdicts", [])}
    final = []
    for f in sorted(state.get("findings", []), key=lambda f: f["id"]):
        v = verdicts.get(f["id"])
        if v and not v.get("supported", True):
            f = {**f, "needs_review": True, "verifier_note": v.get("note", "")}
            if v.get("corrected_summary"):
                f["summary"] = v["corrected_summary"]
        final.append(f)
    _emit("status", {"stage": "Writing executive summary"})
    if final:
        synthesis = await agents.synthesize(final)
    else:
        synthesis = {"executive_summary": "No differences were detected between the two versions.", "themes": [], "risks": []}
    _emit("summary", synthesis)
    return {"final_findings": final, "synthesis": synthesis}


async def build_report(state: State):
    _emit("status", {"stage": "Building report"})
    docx_p, pdf_p = os.path.join(state["out_dir"], "report.docx"), os.path.join(state["out_dir"], "report.pdf")
    args = (state["old_name"], state["new_name"], state["stats"], state["synthesis"], state["final_findings"])
    await asyncio.gather(asyncio.to_thread(report.build, docx_p, *args), asyncio.to_thread(report_pdf.build, pdf_p, *args))
    jid = state["job_id"]
    _emit("done", {"report": f"/api/report/{jid}", "report_pdf": f"/api/report/{jid}.pdf"})
    return {"report_paths": {"docx": docx_p, "pdf": pdf_p}}


# ---------- routing ----------
def after_parse(state: State):
    n = len(state["diffs"])
    return [Send("analyze", {"diff": d, "of": n}) for d in state["diffs"]] or "synthesize"


def after_gather(state: State):
    risky = [f for f in state.get("findings", []) if f.get("impact") == "high" or f.get("needs_review")]
    if not (VERIFY and risky):
        return "synthesize"
    _emit("status", {"stage": f"Verifying {len(risky)} high-impact findings"})
    return [Send("verify", {"finding": f}) for f in risky]


def build_graph(checkpointer=None):
    g = StateGraph(State)
    g.add_node("parse_diff", parse_diff)
    g.add_node("analyze", analyze)
    g.add_node("gather", gather)
    g.add_node("verify", verify)
    g.add_node("synthesize", synthesize)
    g.add_node("report", build_report)
    g.add_edge(START, "parse_diff")
    g.add_conditional_edges("parse_diff", after_parse, ["analyze", "synthesize"])
    g.add_edge("analyze", "gather")
    g.add_conditional_edges("gather", after_gather, ["verify", "synthesize"])
    g.add_edge("verify", "synthesize")
    g.add_edge("synthesize", "report")
    g.add_edge("report", END)
    return g.compile(checkpointer=checkpointer or MemorySaver())


graph = build_graph()
