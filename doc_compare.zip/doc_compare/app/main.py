import asyncio, json, shutil, tempfile, uuid
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .graph import graph

app = FastAPI(title="Document Compare (LangGraph)")
JOBS: dict[str, dict] = {}
ALLOWED = {".pdf", ".docx"}


def emit(job, event, data):
    job["events"].append((event, data))


async def run_job(job, resume=False):
    """Drive the graph. resume=True continues from the last checkpoint instead of starting over."""
    cfg = {"configurable": {"thread_id": job["id"]}}
    state_in = None if resume else {"job_id": job["id"], "old_path": job["old_path"], "new_path": job["new_path"],
                                    "old_name": job["old_name"], "new_name": job["new_name"], "out_dir": job["dir"]}
    try:
        async for chunk in graph.astream(state_in, cfg, stream_mode="custom"):
            if chunk["event"] == "done":
                job["done"] = True
            emit(job, chunk["event"], chunk["data"])
    except Exception as e:
        emit(job, "error", {"message": str(e), "resumable": True})


@app.post("/api/compare")
async def compare(old: UploadFile = File(...), new: UploadFile = File(...)):
    for f in (old, new):
        if Path(f.filename).suffix.lower() not in ALLOWED:
            raise HTTPException(400, "Only .pdf and .docx files are supported.")
    jid = uuid.uuid4().hex[:12]
    d = tempfile.mkdtemp(prefix=f"cmp_{jid}_")
    paths = {}
    for key, f in (("old", old), ("new", new)):
        p = Path(d) / f"{key}{Path(f.filename).suffix.lower()}"
        with open(p, "wb") as out:
            shutil.copyfileobj(f.file, out)
        paths[key] = str(p)
    job = {"id": jid, "dir": d, "old_path": paths["old"], "new_path": paths["new"],
           "old_name": old.filename, "new_name": new.filename, "events": []}
    JOBS[jid] = job
    asyncio.create_task(run_job(job))
    return {"job_id": jid}


@app.post("/api/resume/{jid}")
async def resume(jid: str):
    job = JOBS.get(jid)
    if not job:
        raise HTTPException(404)
    if job.get("done"):
        raise HTTPException(409, "Job already finished.")
    emit(job, "status", {"stage": "Resuming from last checkpoint"})
    asyncio.create_task(run_job(job, resume=True))
    return {"job_id": jid, "after": len(job["events"])}


@app.get("/api/stream/{jid}")
async def stream(jid: str, after: int = 0):
    job = JOBS.get(jid)
    if not job:
        raise HTTPException(404)

    async def gen():
        i = after
        while True:
            while i < len(job["events"]):
                ev, data = job["events"][i]
                i += 1
                yield f"event: {ev}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
                if ev in ("done", "error"):
                    return
            await asyncio.sleep(0.15)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


def _file(jid, key, name, media):
    job = JOBS.get(jid)
    p = Path(job["dir"]) / name if job else None
    if not p or not p.exists():
        raise HTTPException(404, "Report not ready")
    return FileResponse(p, filename=f"comparison_report.{key}", media_type=media)


@app.get("/api/report/{jid}.pdf")
async def get_report_pdf(jid: str):
    return _file(jid, "pdf", "report.pdf", "application/pdf")


@app.get("/api/report/{jid}")
async def get_report(jid: str):
    return _file(jid, "docx", "report.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.get("/api/graph")
async def graph_diagram():
    return {"mermaid": graph.get_graph().draw_mermaid()}


app.mount("/", StaticFiles(directory=Path(__file__).parent / "static", html=True), name="static")
