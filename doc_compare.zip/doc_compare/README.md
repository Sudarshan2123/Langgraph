# Document Compare

Upload an old and a new version (PDF or DOCX), watch findings stream in, download a Word report.

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # add ANTHROPIC_API_KEY
uvicorn app.main:app --reload
# open http://localhost:8000
```

## Pipeline (LangGraph, `app/graph.py`)
```
START -> parse_diff -> analyze x N (parallel, one per changed section) -> gather
      -> verify x M (only high-impact / low-confidence) -> synthesize -> report -> END
```
- Unchanged sections never reach an LLM; no changes -> straight to the summary.
- Fan-out uses LangGraph `Send`; progress streams to the UI over SSE via the custom stream.
- State is checkpointed (`MemorySaver`): `POST /api/resume/{id}` continues a failed run without re-parsing or re-analyzing.
- `GET /api/graph` returns the workflow as a Mermaid diagram. Set `VERIFY_HIGH_IMPACT=0` to skip the verifier.

## Files
- `app/parser.py` common Section structure, header/footer removal
- `app/aligner.py` title + fuzzy matching
- `app/differ.py` sentence diff, table diff keyed on first column
- `app/graph.py` LangGraph workflow, state, routing
- `app/agents.py` prompts (analyze, verify, synthesize), concurrency, prompt caching
- `app/report.py` report template
- `app/main.py` upload, jobs, SSE, download

## Notes
- Jobs and checkpoints are in memory; for production use a persistent checkpointer (e.g. `langgraph-checkpoint-sqlite`/Postgres) and object storage.
- Scanned PDFs need OCR first (e.g. `ocrmypdf in.pdf out.pdf`); Docling can also OCR.
- Tune `MAX_CONCURRENCY` to your API rate limits.
